# Golem Operator Helm Chart

This Helm chart deploys the Golem Operator on a Kubernetes cluster.

## Prerequisites

- Kubernetes 1.12+
- Helm 3.0+

## Installing the Chart

To install the chart with the release name `golem-operator`:

```bash
helm repo add ventus https://ventus-ag.github.io/helm-charts/
helm upgrade -i golem-operator \
  ventus/golem-operator \
  --version 0.1.6 \
  --namespace default \
  --set image.pullPolicy=Always \
  --set image.pullSecret=gotham-registry \
  --set rbac.create=true
```

These commands add the Ventus Helm repository and install the Golem Operator chart with specific configurations.

## Uninstalling the Chart

To uninstall/delete the `golem-operator` deployment:

```bash
helm uninstall golem-operator -n default
```

## Configuration

The following table lists the configurable parameters of the Golem Operator chart and their default values.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.repository` | Image repository | `ghcr.io/ventus-ag/golem-operator` |
| `image.tag` | Image tag | `latest` |
| `image.pullPolicy` | Image pull policy | `Always` |
| `image.pullSecret` | Image pull secret | `""` |
| `replicaCount` | Number of replicas | `1` |
| `rbac.create` | Create RBAC resources | `false` |
| `resources.limits.cpu` | CPU limit | `500m` |
| `resources.limits.memory` | Memory limit | `128Mi` |
| `resources.requests.cpu` | CPU request | `10m` |
| `resources.requests.memory` | Memory request | `64Mi` |

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`. For example:

```bash
helm upgrade -i golem-operator \
  ventus/golem-operator \
  --set replicaCount=2 \
  --set resources.limits.cpu=1
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while installing the chart. For example:

```bash
helm upgrade -i golem-operator ventus/golem-operator -f values.yaml
```